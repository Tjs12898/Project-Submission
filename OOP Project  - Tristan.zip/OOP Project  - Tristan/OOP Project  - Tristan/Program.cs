﻿/*OOP Final Project
Connect 4 Game
Student Name: Tristan John Sagucio
Student ID: 434559*/

using System;

namespace OOPFinalProject
{
    public abstract class Connect4Game
    {

        //Array represents where the token will fall upon users turn
        protected string[] BoardColumn1 { get; set; } = new string[] { "A", "B", "C", "D", "E", "F" };
        protected string[] BoardColumn2 { get; set; } = new string[] { "G", "H", "I", "J", "K", "L" };
        protected string[] BoardColumn3 { get; set; } = new string[] { "M", "N", "O", "P", "Q", "R" };
        protected string[] BoardColumn4 { get; set; } = new string[] { "S", "T", "U", "V", "W", "X" };
        protected string[] BoardColumn5 { get; set; } = new string[] { "Y", "Z", "1", "2", "3", "4" };
        protected string[] BoardColumn6 { get; set; } = new string[] { "5", "6", "7", "8", "9", "0" };
        protected string[] BoardColumn7 { get; set; } = new string[] { "!", "#", "$", "%", "@", "&" };

        //Arrays represent the board columns
        protected string[] UserColumn1 { get; set; } = new string[] { " ", " ", " ", " ", " ", " " };
        protected string[] UserColumn2 { get; set; } = new string[] { " ", " ", " ", " ", " ", " " };
        protected string[] UserColumn3 { get; set; } = new string[] { " ", " ", " ", " ", " ", " " };
        protected string[] UserColumn4 { get; set; } = new string[] { " ", " ", " ", " ", " ", " " };
        protected string[] UserColumn5 { get; set; } = new string[] { " ", " ", " ", " ", " ", " " };
        protected string[] UserColumn6 { get; set; } = new string[] { " ", " ", " ", " ", " ", " " };
        protected string[] UserColumn7 { get; set; } = new string[] { " ", " ", " ", " ", " ", " " };

        protected bool PlayingTime = true;//Boolean variable which identifies that the game is being played.
        protected int PlayerTurn = 0;//Variable that represents players' turn to choose an option.

        public void GameWinner() //The method announces which player wins the game
        {
            if (PlayerTurn % 2 == 0)
            {
                Console.WriteLine("Congratulations player 2 on winning the game!");
            }
            else
            {
                Console.WriteLine("Congratulations player 1 on winning the game");
            }
        }

        protected void IfTie() //The method checks if the game is a tied
        {
            int Cheker1 = Array.IndexOf(UserColumn1, " ");
            int Cheker2 = Array.IndexOf(UserColumn2, " ");
            int Cheker3 = Array.IndexOf(UserColumn3, " ");
            int Cheker4 = Array.IndexOf(UserColumn4, " ");
            int Cheker5 = Array.IndexOf(UserColumn5, " ");
            int Cheker6 = Array.IndexOf(UserColumn6, " ");
            int Cheker7 = Array.IndexOf(UserColumn7, " ");

            if (Cheker1 == -1 && Cheker2 == -1 && Cheker3 == -1 && Cheker4 == -1 && Cheker5 == -1 && Cheker6 == -1 && Cheker7 == -1)
            {
                PlayingTime = false;
                Console.WriteLine("The game is tie");
            }
        }
    }

    public class BoardGame : Connect4Game //This class represents the board and also inherits members from Connect4Game class
    {
        public void DisplayBoard() //Method that displays the boardgame using arrays from Connect4game class
        {
            Console.Clear();
            Console.WriteLine("Welcome to connect four game!");
            Console.WriteLine(" (1) (2) (3) (4) (5) (6) (7)");
            Console.WriteLine($"| {UserColumn1[5]} | {UserColumn2[5]} | {UserColumn3[5]} | {UserColumn4[5]} | {UserColumn5[5]} | {UserColumn6[5]} | {UserColumn7[5]} |");
            Console.WriteLine($"| {UserColumn1[4]} | {UserColumn2[4]} | {UserColumn3[4]} | {UserColumn4[4]} | {UserColumn5[4]} | {UserColumn6[4]} | {UserColumn7[4]} |");
            Console.WriteLine($"| {UserColumn1[3]} | {UserColumn2[3]} | {UserColumn3[3]} | {UserColumn4[3]} | {UserColumn5[3]} | {UserColumn6[3]} | {UserColumn7[3]} |");
            Console.WriteLine($"| {UserColumn1[2]} | {UserColumn2[2]} | {UserColumn3[2]} | {UserColumn4[2]} | {UserColumn5[2]} | {UserColumn6[2]} | {UserColumn7[2]} |");
            Console.WriteLine($"| {UserColumn1[1]} | {UserColumn2[1]} | {UserColumn3[1]} | {UserColumn4[1]} | {UserColumn5[1]} | {UserColumn6[1]} | {UserColumn7[1]} |");
            Console.WriteLine($"| {UserColumn1[0]} | {UserColumn2[0]} | {UserColumn3[0]} | {UserColumn4[0]} | {UserColumn5[0]} | {UserColumn6[0]} | {UserColumn7[0]} |");
        }
    }
    public class PlayGame : BoardGame //This class consists of methods that starts the game and different methods that check differrent ways of winning the game.
    {

        public void PlayersTurn() //This method initializes the game.
        {

            while (PlayingTime)
            {
                DisplayBoard();

                if (PlayerTurn % 2 == 0)
                {
                    Console.WriteLine("Player one's turn - O");
                }
                else
                {
                    Console.WriteLine("Player two's turn - X");
                }

                int UserInput;
                Console.WriteLine("Type a number from 1-7.");
                bool Option = int.TryParse(Console.ReadLine(), out UserInput);

                if (Option)
                {
                    if (UserInput == 1)
                    {
                        int EmptyCell = Array.IndexOf(UserColumn1, " ");
                        if (EmptyCell == -1)
                        {
                            Console.WriteLine("That place is already occupied!");
                        }
                        else if (PlayerTurn % 2 == 0)
                        {
                            PlayerTurn++;
                            BoardColumn1[EmptyCell] = "O";
                            UserColumn1[EmptyCell] = "O";
                        }
                        else
                        {
                            PlayerTurn++;
                            BoardColumn1[EmptyCell] = "X";
                            UserColumn1[EmptyCell] = "X";
                        }
                        DisplayBoard();
                        VerticalWin();
                        HorizontalWin();
                        DiagonalWin();
                        IfTie();
                    }
                    else if (UserInput == 2)
                    {
                        int EmptyCell = Array.IndexOf(UserColumn2, " ");
                        if (EmptyCell == -1)
                        {
                            Console.WriteLine("That place is already occupied!");
                        }
                        else if (PlayerTurn % 2 == 0)
                        {
                            PlayerTurn++;
                            BoardColumn2[EmptyCell] = "O";
                            UserColumn2[EmptyCell] = "O";
                        }
                        else
                        {
                            PlayerTurn++;
                            BoardColumn2[EmptyCell] = "X";
                            UserColumn2[EmptyCell] = "X";
                        }
                        DisplayBoard();
                        VerticalWin();
                        HorizontalWin();
                        DiagonalWin();
                        IfTie();
                    }
                    else if (UserInput == 3)
                    {
                        int EmptyCell = Array.IndexOf(UserColumn3, " ");
                        if (EmptyCell == -1)
                        {
                            Console.WriteLine("That place is already occupied!");
                        }
                        else if (PlayerTurn % 2 == 0)
                        {
                            PlayerTurn++;
                            BoardColumn3[EmptyCell] = "O";
                            UserColumn3[EmptyCell] = "O";
                        }
                        else
                        {
                            PlayerTurn++;
                            BoardColumn3[EmptyCell] = "X";
                            UserColumn3[EmptyCell] = "X";
                        }
                        DisplayBoard();
                        VerticalWin();
                        HorizontalWin();
                        DiagonalWin();
                        IfTie();
                    }
                    else if (UserInput == 4)
                    {
                        int EmptyCell = Array.IndexOf(UserColumn4, " ");
                        if (EmptyCell == -1)
                        {
                            Console.WriteLine("That place is already occupied!");
                        }
                        else if (PlayerTurn % 2 == 0)
                        {
                            PlayerTurn++;
                            BoardColumn4[EmptyCell] = "O";
                            UserColumn4[EmptyCell] = "O";
                        }
                        else
                        {
                            PlayerTurn++;
                            BoardColumn4[EmptyCell] = "X";
                            UserColumn4[EmptyCell] = "X";
                        }
                        DisplayBoard();
                        VerticalWin();
                        HorizontalWin();
                        DiagonalWin();
                        IfTie();
                    }
                    else if (UserInput == 5)
                    {
                        int EmptyCell = Array.IndexOf(UserColumn5, " ");
                        if (EmptyCell == -1)
                        {
                            Console.WriteLine("That place is already occupied!");
                        }
                        else if (PlayerTurn % 2 == 0)
                        {
                            PlayerTurn++;
                            BoardColumn5[EmptyCell] = "O";
                            UserColumn5[EmptyCell] = "O";
                        }
                        else
                        {
                            PlayerTurn++;
                            BoardColumn5[EmptyCell] = "X";
                            UserColumn5[EmptyCell] = "X";
                        }
                        DisplayBoard();
                        VerticalWin();
                        HorizontalWin();
                        DiagonalWin();
                        IfTie();
                    }
                    else if (UserInput == 6)
                    {
                        int EmptyCell = Array.IndexOf(UserColumn6, " ");
                        if (EmptyCell == -1)
                        {
                            Console.WriteLine("That place is already occupied!");
                        }
                        else if (PlayerTurn % 2 == 0)
                        {
                            PlayerTurn++;
                            BoardColumn6[EmptyCell] = "O";
                            UserColumn6[EmptyCell] = "O";
                        }
                        else
                        {
                            PlayerTurn++;
                            BoardColumn6[EmptyCell] = "x";
                            UserColumn6[EmptyCell] = "x";
                        }
                        DisplayBoard();
                        VerticalWin();
                        HorizontalWin();
                        DiagonalWin();
                        IfTie();
                    }
                    else if (UserInput == 7)
                    {
                        int EmptyCell = Array.IndexOf(UserColumn7, " ");
                        if (EmptyCell == -1)
                        {
                            Console.WriteLine("That place is already occupied!");
                        }
                        else if (PlayerTurn % 2 == 0)
                        {
                            PlayerTurn++;
                            BoardColumn7[EmptyCell] = "O";
                            UserColumn7[EmptyCell] = "O";
                        }
                        else
                        {
                            PlayerTurn++;
                            BoardColumn7[EmptyCell] = "X";
                            UserColumn7[EmptyCell] = "X";
                        }
                        DisplayBoard();
                        VerticalWin();
                        HorizontalWin();
                        DiagonalWin();
                        IfTie();
                    }
                    else if (UserInput > 7 || UserInput < 0)
                    {
                        Console.WriteLine("Please enter a valid number from 1-7");
                    }
                }

                else
                {
                    Console.WriteLine("Please enter a valid number from 1-7");
                }
            }
        }

        public void VerticalWin() //This method checks if the player gets four vertical combination to win the game 
        {
            if (BoardColumn1[0] == BoardColumn1[1] && BoardColumn1[0] == BoardColumn1[2] && BoardColumn1[0] == BoardColumn1[3] || BoardColumn1[1] == BoardColumn1[2] && BoardColumn1[1] == BoardColumn1[3] && BoardColumn1[1] == BoardColumn1[4] || BoardColumn1[2] == BoardColumn1[3] && BoardColumn1[2] == BoardColumn1[4] && BoardColumn1[2] == BoardColumn1[5])
            {
                PlayingTime = false;
                GameWinner();
            }
            else if (BoardColumn2[0] == BoardColumn2[1] && BoardColumn2[0] == BoardColumn2[2] && BoardColumn2[0] == BoardColumn2[3] || BoardColumn2[1] == BoardColumn2[2] && BoardColumn2[1] == BoardColumn2[3] && BoardColumn2[1] == BoardColumn2[4] || BoardColumn2[2] == BoardColumn2[3] && BoardColumn2[2] == BoardColumn2[4] && BoardColumn2[2] == BoardColumn2[5])
            {
                PlayingTime = false;
                GameWinner();
            }
            else if (BoardColumn3[0] == BoardColumn3[1] && BoardColumn3[1] == BoardColumn3[2] && BoardColumn3[2] == BoardColumn3[3] || BoardColumn3[1] == BoardColumn3[2] && BoardColumn3[1] == BoardColumn3[3] && BoardColumn3[1] == BoardColumn3[4] || BoardColumn3[2] == BoardColumn3[3] && BoardColumn3[2] == BoardColumn3[4] && BoardColumn3[2] == BoardColumn3[5])
            {
                PlayingTime = false;
                GameWinner();
            }
            else if (BoardColumn4[0] == BoardColumn4[1] && BoardColumn4[1] == BoardColumn4[2] && BoardColumn4[0] == BoardColumn4[3] || BoardColumn4[1] == BoardColumn4[2] && BoardColumn4[1] == BoardColumn4[3] && BoardColumn4[1] == BoardColumn4[4] || BoardColumn4[2] == BoardColumn4[3] && BoardColumn4[2] == BoardColumn4[4] && BoardColumn4[2] == BoardColumn4[5])
            {
                PlayingTime = false;
                GameWinner();
            }
            else if (BoardColumn5[0] == BoardColumn5[1] && BoardColumn5[1] == BoardColumn5[2] && BoardColumn5[2] == BoardColumn5[3] || BoardColumn5[1] == BoardColumn5[2] && BoardColumn5[1] == BoardColumn5[3] && BoardColumn5[1] == BoardColumn5[4] || BoardColumn5[2] == BoardColumn5[3] && BoardColumn5[2] == BoardColumn5[4] && BoardColumn5[2] == BoardColumn5[5])
            {
                PlayingTime = false;
                GameWinner();
            }
            else if (BoardColumn6[0] == BoardColumn6[1] && BoardColumn6[1] == BoardColumn6[2] && BoardColumn6[2] == BoardColumn6[3] || BoardColumn6[1] == BoardColumn6[2] && BoardColumn6[1] == BoardColumn6[3] && BoardColumn6[1] == BoardColumn6[4] || BoardColumn6[2] == BoardColumn6[3] && BoardColumn6[2] == BoardColumn6[4] && BoardColumn6[2] == BoardColumn6[5])
            {
                PlayingTime = false;
                GameWinner();
            }
            else if (BoardColumn7[0] == BoardColumn7[1] && BoardColumn7[1] == BoardColumn7[2] && BoardColumn7[2] == BoardColumn7[3] || BoardColumn7[1] == BoardColumn7[2] && BoardColumn7[1] == BoardColumn7[3] && BoardColumn7[1] == BoardColumn7[4] || BoardColumn7[2] == BoardColumn7[3] && BoardColumn7[2] == BoardColumn7[4] && BoardColumn7[2] == BoardColumn7[5])
            {
                PlayingTime = false;
                GameWinner();
            }
        }

        public void DiagonalWin() //This method checks if the player gets diagonal combination that wins the game.
        {
            if (BoardColumn1[0] == BoardColumn2[1] && BoardColumn1[0] == BoardColumn3[2] && BoardColumn1[0] == BoardColumn4[3] || BoardColumn1[1] == BoardColumn2[2] && BoardColumn1[1] == BoardColumn3[3] && BoardColumn1[1] == BoardColumn4[4] || BoardColumn1[2] == BoardColumn2[3] && BoardColumn1[2] == BoardColumn3[4] && BoardColumn1[2] == BoardColumn4[5])
            {
                PlayingTime = false;
                GameWinner();
            }
            else if (BoardColumn1[5] == BoardColumn2[4] && BoardColumn1[5] == BoardColumn3[3] && BoardColumn1[5] == BoardColumn4[2] || BoardColumn1[4] == BoardColumn2[3] && BoardColumn1[4] == BoardColumn3[2] && BoardColumn1[4] == BoardColumn4[1] || BoardColumn1[3] == BoardColumn2[2] && BoardColumn1[3] == BoardColumn3[1] && BoardColumn1[3] == BoardColumn4[0])
            {
                PlayingTime = false;
                GameWinner();
            }

            else if (BoardColumn2[0] == BoardColumn3[1] && BoardColumn2[0] == BoardColumn4[2] && BoardColumn2[0] == BoardColumn5[3] || BoardColumn2[1] == BoardColumn3[2] && BoardColumn2[1] == BoardColumn4[3] && BoardColumn2[1] == BoardColumn5[4] || BoardColumn2[2] == BoardColumn3[3] && BoardColumn4[2] == BoardColumn2[4] && BoardColumn2[2] == BoardColumn5[5])
            {
                PlayingTime = false;
                GameWinner();
            }
            else if (BoardColumn2[5] == BoardColumn3[4] && BoardColumn2[5] == BoardColumn4[3] && BoardColumn2[5] == BoardColumn5[2] || BoardColumn2[4] == BoardColumn3[3] && BoardColumn2[4] == BoardColumn4[2] && BoardColumn2[4] == BoardColumn5[1] || BoardColumn2[3] == BoardColumn3[2] && BoardColumn4[3] == BoardColumn2[1] && BoardColumn2[3] == BoardColumn5[0])
            {
                PlayingTime = false;
                GameWinner();
            }

            else if (BoardColumn3[0] == BoardColumn4[1] && BoardColumn3[0] == BoardColumn5[2] && BoardColumn3[0] == BoardColumn6[3] || BoardColumn3[1] == BoardColumn4[2] && BoardColumn3[1] == BoardColumn5[3] && BoardColumn3[1] == BoardColumn6[4] || BoardColumn3[2] == BoardColumn4[3] && BoardColumn3[2] == BoardColumn5[4] && BoardColumn3[2] == BoardColumn6[5])
            {
                PlayingTime = false;
                GameWinner();
            }
            else if (BoardColumn3[5] == BoardColumn4[4] && BoardColumn3[5] == BoardColumn5[3] && BoardColumn3[5] == BoardColumn6[2] || BoardColumn3[4] == BoardColumn4[3] && BoardColumn3[4] == BoardColumn5[2] && BoardColumn3[4] == BoardColumn6[1] || BoardColumn3[3] == BoardColumn4[2] && BoardColumn3[3] == BoardColumn5[1] && BoardColumn3[3] == BoardColumn6[0])
            {
                PlayingTime = false;
                GameWinner();
            }

            else if (BoardColumn4[0] == BoardColumn5[1] && BoardColumn4[0] == BoardColumn6[2] && BoardColumn4[0] == BoardColumn7[3] || BoardColumn4[1] == BoardColumn5[2] && BoardColumn4[1] == BoardColumn6[3] && BoardColumn4[1] == BoardColumn7[4] || BoardColumn4[2] == BoardColumn5[3] && BoardColumn4[2] == BoardColumn6[4] && BoardColumn4[2] == BoardColumn7[5])
            {
                PlayingTime = false;
                GameWinner();
            }
            else if (BoardColumn4[5] == BoardColumn5[4] && BoardColumn4[5] == BoardColumn6[3] && BoardColumn4[5] == BoardColumn7[2] || BoardColumn4[4] == BoardColumn5[3] && BoardColumn4[4] == BoardColumn6[2] && BoardColumn4[4] == BoardColumn7[1] || BoardColumn4[3] == BoardColumn5[2] && BoardColumn4[3] == BoardColumn6[1] && BoardColumn4[3] == BoardColumn7[0])
            {
                PlayingTime = false;
                GameWinner();
            }
        }

        public void HorizontalWin() //This method checks if the player gets horizontal combination that wins the game.
        {
            if (BoardColumn1[0] == BoardColumn2[0] && BoardColumn1[0] == BoardColumn3[0] && BoardColumn1[0] == BoardColumn4[0])
            {
                PlayingTime = false;
                GameWinner();
            }
            else if (BoardColumn1[1] == BoardColumn2[1] && BoardColumn1[1] == BoardColumn3[1] && BoardColumn1[1] == BoardColumn4[1])
            {
                PlayingTime = false;
                GameWinner();
            }
            else if (BoardColumn1[2] == BoardColumn2[2] && BoardColumn1[2] == BoardColumn3[2] && BoardColumn1[2] == BoardColumn4[2])
            {
                PlayingTime = false;
                GameWinner();
            }
            else if (BoardColumn1[3] == BoardColumn2[3] && BoardColumn1[3] == BoardColumn3[3] && BoardColumn1[3] == BoardColumn4[3])
            {
                PlayingTime = false;
                GameWinner();
            }
            else if (BoardColumn1[4] == BoardColumn2[4] && BoardColumn1[4] == BoardColumn3[4] && BoardColumn1[4] == BoardColumn4[4])
            {
                PlayingTime = false;
                GameWinner();
            }
            else if (BoardColumn1[5] == BoardColumn2[5] && BoardColumn1[5] == BoardColumn3[5] && BoardColumn1[5] == BoardColumn4[5])
            {
                PlayingTime = false;
                GameWinner();
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            PlayGame StartGame = new PlayGame();
            StartGame.PlayersTurn();
        }

    }
}